#pragma once

void xmr_jh256(const BitSequence *data, BitSequence *hashval);
