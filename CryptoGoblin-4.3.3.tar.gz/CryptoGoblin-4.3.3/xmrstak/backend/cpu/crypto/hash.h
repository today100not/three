#pragma once

#include <stdint.h>

typedef unsigned char BitSequence;
typedef uint32_t DataLength;
